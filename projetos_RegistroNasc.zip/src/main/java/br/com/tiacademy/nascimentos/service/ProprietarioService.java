package br.com.tiacademy.nascimentos.service;

import br.com.tiacademy.nascimentos.domain.proprietario;
import br.com.tiacademy.nascimentos.repository.ProprietarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class ProprietarioService {

   @Autowired
   private static ProprietarioRepository ProprietarioRepository ;

   public static List<proprietario> listar(){
       return ProprietarioRepository.findAll();
    }

    public static proprietario porId(Long id){
        return ProprietarioRepository.findById(id).orElse(null);
    }

    public proprietario criar(proprietario Proprietario){
       return ProprietarioRepository.save(Proprietario);
    }

    public proprietario editar(Long id, proprietario editado){
        var recuperado= porId(id);

        if (Objects.isNull(recuperado)){
            //tratar null
            throw new RuntimeException("não foi encontrado");
        }
        recuperado.setNome(editado.getNome());

        return ProprietarioRepository.save(recuperado);
    }

    // usa void pois não retorna nada

    public void excluir(Long id){
       ProprietarioRepository.deleteById(id);
    }
}
