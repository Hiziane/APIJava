package br.com.tiacademy.nascimentos.repository;

import br.com.tiacademy.nascimentos.domain.proprietario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface ProprietarioRepository  extends JpaRepository<proprietario,Long>{

}
