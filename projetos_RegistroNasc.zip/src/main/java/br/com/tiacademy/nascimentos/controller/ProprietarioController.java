package br.com.tiacademy.nascimentos.controller;

import br.com.tiacademy.nascimentos.domain.proprietario;
import br.com.tiacademy.nascimentos.repository.ProprietarioRepository;
import br.com.tiacademy.nascimentos.service.ProprietarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

import static br.com.tiacademy.nascimentos.service.ProprietarioService.porId;

@RestController
@RequestMapping("/proprietario")

public class ProprietarioController {

    @Autowired
    private ProprietarioService proprietarioService;


    @GetMapping
    public ResponseEntity<List<proprietario>>listar(){
        var proprietarios =  ProprietarioService.listar();

        return ResponseEntity.ok(proprietarios);
    }

    @GetMapping("/{id}")
    public ResponseEntity<proprietario>especifico(@PathVariable("id") Long id){
       var resultado= porId(id);

       if (Objects.isNull(resultado)){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(resultado);
    }


    @PostMapping
    public ResponseEntity<proprietario>criar(@RequestBody proprietario Proprietario){
        var resultado=  proprietarioService.criar(Proprietario);

       return ResponseEntity.ok(resultado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<proprietario>editar(@PathVariable("id") Long id,@RequestBody proprietario Proprietario){
        return ResponseEntity.ok(proprietarioService.editar(id,Proprietario));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void>excluir(@PathVariable("id") Long id){
        proprietarioService.excluir(id);
        return ResponseEntity.ok().build();
    }

}
