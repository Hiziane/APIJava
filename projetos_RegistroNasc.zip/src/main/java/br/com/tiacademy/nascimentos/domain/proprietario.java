package br.com.tiacademy.nascimentos.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class proprietario {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private Long idprop;
    private String nome;

    public Long getIdprop() {
        return idprop;
    }

    public void setIdprop(Long idprop) {
        this.idprop = idprop;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public proprietario(Long idprop, String nome){
        this.idprop=idprop;
        this.nome=nome;
    }

    public proprietario(){

    }
}
