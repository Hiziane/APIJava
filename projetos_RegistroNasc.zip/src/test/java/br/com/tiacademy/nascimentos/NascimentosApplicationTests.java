package br.com.tiacademy.nascimentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NascimentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
